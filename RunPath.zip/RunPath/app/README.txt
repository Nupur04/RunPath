Application as per requirements is developed. Additional 	dropdown to select number of items per page logic also added.

Pre-requisite : 
node.js
npm installed

To Run :
open cmd from project's root folder. (RunPath\app)
command : http-server -o

NOTE : I have changed file extensions from js to txt so that I could attach and send, please change it back once you download the application.

index.txt ----> index.js
DataController.txt ----> DataController.js
app\angular.min.txt ----> angular.min.js
app\angular-route.min.txt ----> angular-route.min.js



