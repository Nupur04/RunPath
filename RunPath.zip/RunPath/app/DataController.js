var App = angular.module('myApp', [])
    .controller('DataController', ['$scope', '$http', '$filter', function DataController($scope, $http, $filter) {
        $scope.content = null;
        $scope.currPage = 0;
        $scope.pageSize = '10';
        $scope.items = [];
        $scope.searchString = '';

        $http.get('http://jsonplaceholder.typicode.com/photos').
        success(function(data) {
            $scope.items = data;
        }).error(function(data) {
            alert("something went wrong");
        });

        $scope.filterData = function() {
            return $filter('filter')($scope.items, $scope.searchString);
        }

        $scope.totalPages =function() {
                return Math.ceil($scope.filterData().length / $scope.pageSize);
        };

        $scope.$watch('searchString', function(finalValue, lastValue){
            if(lastValue != finalValue){
                $scope.currPage = 0;
            }
        }, true);
    }]);

App.filter('startFrom', function() {
    if (typeof input === undefined) {
        return null;
    } else {
        return function(input, start) {
            start = +start; 
            return input.slice(start);
        }
    }
});