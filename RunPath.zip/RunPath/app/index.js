var App = angular.module('myApp');

angular.module('myApp')
    .component("runPath", {
        templateUrl: 'run-path.component.html',
        controller: 'DataController',
    });